package com.adamrosyad.aaaaaaaaaaisyah;

public class trans {
    String kdtrans, kdbar, nambar, satbar;
    int hrgbar, jml, tot;

    public trans(String kdtrans, String kdbar, String nambar, String satbar, int hrgbar, int jml, int tot) {
        this.kdtrans = kdtrans;
        this.kdbar = kdbar;
        this.nambar = nambar;
        this.satbar = satbar;
        this.hrgbar = hrgbar;
        this.jml = jml;
        this.tot = tot;
    }

    public String getKdtrans() {
        return kdtrans;
    }

    public void setKdtrans(String kdtrans) {
        this.kdtrans = kdtrans;
    }

    public String getKdbar() {
        return kdbar;
    }

    public void setKdbar(String kdbar) {
        this.kdbar = kdbar;
    }

    public String getNambar() {
        return nambar;
    }

    public void setNambar(String nambar) {
        this.nambar = nambar;
    }

    public String getSatbar() {
        return satbar;
    }

    public void setSatbar(String satbar) {
        this.satbar = satbar;
    }

    public int getHrgbar() {
        return hrgbar;
    }

    public void setHrgbar(int hrgbar) {
        this.hrgbar = hrgbar;
    }

    public int getJml() {
        return jml;
    }

    public void setJml(int jml) {
        this.jml = jml;
    }

    public int getTot() {
        return tot;
    }

    public void setTot(int tot) {
        this.tot = tot;
    }
}
