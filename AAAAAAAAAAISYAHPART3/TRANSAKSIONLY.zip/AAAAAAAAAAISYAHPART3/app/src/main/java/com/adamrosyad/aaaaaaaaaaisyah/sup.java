package com.adamrosyad.aaaaaaaaaaisyah;

public class sup {
    String id, nama, alamat, tlp;

    public sup(String id, String nama, String alamat, String tlp) {
        this.id = id;
        this.nama = nama;
        this.alamat = alamat;
        this.tlp = tlp;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getTlp() {
        return tlp;
    }

    public void setTlp(String tlp) {
        this.tlp = tlp;
    }
}
