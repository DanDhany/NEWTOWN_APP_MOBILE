package com.adamrosyad.aaaaaaaaaaisyah;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ActivityLogin extends AppCompatActivity {

    EditText txtusername, txtpass;
    Button login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        txtusername = (EditText)findViewById(R.id.txtusername);
        txtpass = (EditText)findViewById(R.id.txtpass);
        login = (Button) findViewById(R.id.login);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(txtusername.getText().toString().equals("admin")&&txtpass.getText().toString().equals("admin")||txtusername.getText().toString().equals("Adam Rosyad")&&txtpass.getText().toString().equals("adamrosyad12")){
                    Toast.makeText(ActivityLogin.this,"Selamat Datang "+txtusername.getText(), Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(ActivityLogin.this, ActivityHome.class);
                    startActivity(intent);
                }else{
                    Toast.makeText(ActivityLogin.this,"Username atau Password Salah Mohon Periksa Kembali", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
