package com.adamrosyad.aaaaaaaaaaisyah;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

public class ActivityEditUser extends AppCompatActivity {

    EditText id, nama, alamat, tlp, pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_user);

        id = (EditText)findViewById(R.id.inputid);
        nama = (EditText)findViewById(R.id.inputnama);
        alamat = (EditText)findViewById(R.id.inputalamat);
        tlp = (EditText)findViewById(R.id.inputtelp);
        pass = (EditText)findViewById(R.id.inputpass);

        Intent intent = getIntent();
        String idd = intent.getStringExtra("sendid");
        String namaa = intent.getStringExtra("sendnama");
        String alamatt = intent.getStringExtra("sendalamat");
        String tlpp = intent.getStringExtra("sendtelp");
        String passs = intent.getStringExtra("sendpass");

        id.setText(idd);
        nama.setText(namaa);
        alamat.setText(alamatt);
        tlp.setText(tlpp);
        pass.setText(passs);
    }
}
