package com.adamrosyad.aaaaaaaaaaisyah;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.List;

public class UserAdapter extends ArrayAdapter<user>{
    Context mctx;
    int listLayoutRes;
    private List<user> userlist;
    SQLiteDatabase db;

    public UserAdapter(Context mctx, int listLayoutRes, List<user> userlist, SQLiteDatabase db) {
        super(mctx, listLayoutRes, userlist);
        this.mctx = mctx;
        this.listLayoutRes = listLayoutRes;
        this.userlist = userlist;
        this.db = db;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(mctx);
        View view = inflater.inflate(listLayoutRes, null);

        user User = userlist.get(position);

        TextView id = view.findViewById(R.id.iduser);
        TextView nama = view.findViewById(R.id.namauser);
        TextView alamat = view.findViewById(R.id.alamatuser);
        TextView tlp = view.findViewById(R.id.tlpuser);
        TextView pass = view.findViewById(R.id.passuser);
        TextView akses = view.findViewById(R.id.aksesuser);

        id.setText(User.getId());
        nama.setText(User.getNama());
        alamat.setText(User.getAlamat());
        tlp.setText(User.getTlp());
        akses.setText(User.getAkses());
        pass.setText(User.getPass());

        return view;
    }

}
